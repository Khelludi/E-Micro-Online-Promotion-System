<?php 
	class Categories extends CI_Controller{
		public function index(){
			$data['title'] ='Categories';

			$data['categories']=$this->categorymodel->getCategories();

			$this->load->view('templates/header');
				$this->load->view('categories/index',$data);
				$this->load->view('templates/footer');
		}
		public function create(){
			$data['title']='Create Category';

			$this->form_validation->set_rules('cname','Name','required');
			if ($this->form_validation->run() === FALSE) {
				$this->load->view('templates/header');
				$this->load->view('categories/create',$data);
				$this->load->view('templates/footer');
			}else{
				$this->categorymodel->createCategory();
				$this->session->set_flashdata('category_created','Category created');
				redirect('categories');
			}
		}
		public function products($id){
			$data['title']=$this->categorymodel->getCategory($id)->cname;
			$data['products']=$this->productmodel->getProductByCategory($id);

				$this->load->view('templates/header');
				$this->load->view('products/index',$data);
				$this->load->view('templates/footer');
		}	

}
 ?>