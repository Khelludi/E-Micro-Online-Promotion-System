<?php 
	class UserModel extends CI_Model{
		public function register($enc_password){
			//users data array

			$data=array(
				'enterprise_name'=>$this->input->post('enterprise_name'),
				'email'=>$this->input->post('email'),
				'username'=>$this->input->post('username'),
				'password'=>$enc_password,
				'license_number'=>$this->input->post('license_number')
			);
			// insert user
			return $this->db->insert('users',$data);
		}
		//log in user
		public function login($username,$password){
			//validate
			$this->db->where('username',$username);
			$this->db->where('password',$password);

			$result=$this->db->get('users');
			$num_row = $result->num_rows();
			$row = $result->first_row();
			if ($result->num_rows()==1) {
				if($row->level === '1'){
					return '1';

				}
				elseif($row->level === '2'){
					return '2';
				}
			}else{
				return false;
			}
		}
		public function checkUser($username,$password){
			$this->db->where('username',$username);
			$this->db->where('password',$password);

			$result=$this->db->get('users');
			return $result->row(0)->id;
			#$num_row = $result->num_rows();
			#$row = $result->first_row();
		}
		//check username exists
		public function checkUsernameExists($username){
			$query=$this->db->get_where('users',array('username'=>$username));
			if (empty($query->row_array())) {
				return true;
			}else{
				return false;
			}
		}
		//check email exists
		public function checkEmailExists($email){
			$query=$this->db->get_where('users',array('email'=>$email));
			if (empty($query->row_array())) {
				return true;
			}else{
				return false;
			}
		}
		public function deleteUsers($id){
			$this->db->where('id',$id);
			$this->db->delete('users');
			return true;
		}
		public function getUsers($level){
			$this->db->order_by('id','DESC');
			$query=$this->db->get_where('users',array('level'=>$level));
			return $query->result_array();
		}
		public function checkLicenseExists($license_number){
			$query=$this->db->get_where('users',array('license_number'=>$license_number));
			if (empty($query->row_array())) {
				return true;
			}else{
				return false;
			}
		}
	}



 ?>