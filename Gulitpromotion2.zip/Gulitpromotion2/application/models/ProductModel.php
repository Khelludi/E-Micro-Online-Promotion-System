<?php 
	class ProductModel extends CI_Model{
		public function __construct(){
			$this->load->database();
		}
		public function getProducts($slag=False){
			if ($slag===False) {
				$this->db->order_by('products.id','DESC');
				$this->db->join('categories','categories.id=products.category_id');
				$query =$this ->db->get('products');
				return $query->result_array();
			}

			$query=$this->db->get_where('products',array('slag'=>$slag));
			return $query->row_array();
		}
		public function uploadProduct($product_image){

			$slag = url_title($this->input->post('name'));
			$data = array('name'=>$this->input->post('name'),
				'slag'=>$slag,
				'description'=>$this->input->post('description'),
				'price'=>$this->input->post('price'),
				'contact'=>$this->input->post('contact'),
				'address'=>$this->input->post('address'),
				'category_id' => $this->input->post('category_id'),
				'user_id'=>$this->session->userdata('user_id'),
				'product_image'=>$product_image 
		);
			return $this->db->insert('products',$data);
		}
		public function updateProduct($product_image){
			$slag = url_title($this->input->post('name'));
			$data = array('name'=>$this->input->post('name'),'slag'=>$slag,'description'=>$this->input->post('description'),
				'price'=>$this->input->post('price'),
				'contact'=>$this->input->post('contact'),
				'user_id'=>$this->input->post('user_id'),
				'address'=>$this->input->post('address'),
			'category_id' => $this->input->post('category_id') ,
			'product_image'=>$product_image  
				);
			$this->db->where('user_id',$this->input->post('user_id'));
			return $this->db->update('products',$data);  
		}
		public function getCategories(){
			$this->db->order_by('cname');
			$query = $this->db->get('categories');
			return $query->result_array();
		}

		public function getProductByCategory($category_id){
			$this->db->order_by('products.id','DESC');
			$this->db->join('categories','categories.id=products.category_id');
				$query =$this ->db->get_where('products',array('category_id'=>$category_id));
				return $query->result_array();
		}
}

 ?>