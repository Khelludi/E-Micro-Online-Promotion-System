<?php 
	class NewsModel extends CI_Model{
		public function __construct(){
			$this->load->database();
		}
		public function getNews($n_slag=FALSE){
			if($n_slag ===FALSE){
				$this->db->order_by('id','DESC');
				$query=$this->db->get('news');
				return $query->result_array();
			}

			$query=$this->db->get_where('news',array('n_slag'=>$n_slag));
			return $query->row_array();
		}
		public function uploadNews($news_image){

			$n_slag = url_title($this->input->post('title'));
			$data = array('n_title'=>$this->input->post('title'),'n_slag'=>$n_slag,'news'=>$this->input->post('news'),'level'=>'1',
				'news_image'=>$news_image 
		);
			return $this->db->insert('news',$data);
		}

		public function updateNews($news_image){
			$n_slag = url_title($this->input->post('title'));
			$data = array('n_title'=>$this->input->post('title'),'n_slag'=>$n_slag,'news'=>$this->input->post('news'),
				'news_image'=>$news_image
				);
			$this->db->where('id',$this->input->post('id'));
			return $this->db->update('news',$data);  
		}
	
	}
	

 ?>