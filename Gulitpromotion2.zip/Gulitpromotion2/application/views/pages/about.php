<h2><?=$title ?></h2>
<p>this is gulit version 1.0</p>