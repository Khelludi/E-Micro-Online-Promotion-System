<?php  
	class Users extends CI_Controller{
		//register user
		public function register(){
			$data['title']='signup';

			$this->form_validation->set_rules('enterprise_name','Enterprise Name','required');
			$this->form_validation->set_rules('license_number','License Number','required|callback_checkLicenseExists');
			$this->form_validation->set_rules('username','Username','required|callback_checkUsernameExists');
			$this->form_validation->set_rules('email','Email','required|callback_checkEmailExists');
			$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]');
			$this->form_validation->set_rules('password2', 'Password Confirmation', 'trim|required|matches[password]');
			if($this->form_validation->run()===FALSE){
				$this->load->view('templates/header');
				$this->load->view('users/register',$data);
				$this->load->view('templates/footer');

			}else{
				//Encrypt password
				$enc_password=md5($this->input->post('password'));
				$this->usermodel->register($enc_password);
				//set message
				$this->session->set_flashdata('user_registered','You are now registered and can log in');
				redirect('users/login');
			}
		}
		//Login user
		public function login(){
			$data['title']='Sign In';
			$this->form_validation->set_rules('username','Username','required');
			$this->form_validation->set_rules('password', 'Password', 'required');

			if($this->form_validation->run()===FALSE){
				$this->load->view('templates/header');
				$this->load->view('users/login',$data);
				$this->load->view('templates/footer');

			}else{  
					//get user name
				$username=$this->input->post('username');
				//get and encrypt the password
				$password=md5($this->input->post('password'));
				//login user
				$level=$this->usermodel->login($username,$password);
				$user_id=$this->usermodel->checkUser($username,$password);
				if ($level==='1') {
					//create session
					$user_data=array(
						'user_id'=>$user_id,
						'user_name'=>$username,
						'level'=>$level,
						'logged_in' =>true
						
					);
					$this->session->set_userdata($user_data);
					$this->session->set_flashdata('user_loggedin','You are now  logged in');
					redirect('adminstrators');

				}elseif($level==='2'){
						$user_data=array(
						'user_id'=>$user_id,
						'user_name'=>$username,
						'level'=>$level,
						'logged_in' =>true);
						$this->session->set_userdata($user_data);
						$this->session->set_flashdata('user_loggedin','You are now  logged in');
							redirect('products');
				
				}
				else{
					//set message
				$this->session->set_flashdata('login_failed','Login is invalid');
				redirect('users/login');
				}
				
			}
		}
		//log user out
		public function logout(){
			//unset userdata
			$this->session->unset_userdata('logged_in');
			$this->session->unset_userdata('user_id');
			$this->session->unset_userdata('username');
			$this->session->unset_userdata('level');
			$this->session->sess_destroy();
			//set message
				$this->session->set_flashdata('user_loggedout','You are now logged out');
				redirect('users/login');
				}
		
		//check if user name exists
		public function checkUsernameExists($username){
			$this->form_validation->set_message('checkUsernameExists','That username is taken please choose a diffrent one');
			if ($this->usermodel->checkUsernameExists($username)) {
				return true;
			}else{
				return false;
			}
		}
		public function checkEmailExists($email){
			$this->form_validation->set_message('checkEmailExists','That email is taken please choose a diffrent one');
			if ($this->usermodel->checkEmailExists($email)) {
				return true;
			}else{
				return false;
			}
		}
		public function checkLicenseExists($license_number){
			$this->form_validation->set_message('checkLicenseExists','That License Number is already in use');
			if ($this->usermodel->checkLicenseExists($license_number)) {
				return true;
			}else{
				return false;
			}
		}
		
	}
?>