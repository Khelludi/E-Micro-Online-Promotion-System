<h2><?= $title; ?></h2>
<section class="section1">
	
</section>
<section class="section2">
	
</section>