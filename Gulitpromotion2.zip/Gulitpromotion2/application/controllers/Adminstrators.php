<?php 
	class Adminstrators extends CI_Controller{
		public function index(){
			if(!$this->session->userdata('logged_in')){
				$this->session->set_flashdata('login_failed','you need adminstative privilage');
				redirect('users/login');
			}
			$data['title']='Adminstrator Page';
			
			$this->load->view('templates/header3');
			$this->load->view('pages/home',$data);
			$this->load->view('templates/footer');
		}
		public function listUsers(){
			if(!$this->session->userdata('logged_in')){
				$this->session->set_flashdata('login_failed','you need adminstative privilage');
				redirect('users/login');
			}
			$level='2';
			$data['title']='Adminstrator Page';
			$data['users']=$this->usermodel->getUsers($level);
			$this->load->view('templates/header');
			$this->load->view('adminstrator/userslist',$data);
			$this->load->view('templates/footer');
		}
		public function delete($id){
			$this->usermodel->deleteUsers($id);
			$this->session->set_flashdata('post_updated','user success fully deleted');
			redirect('adminstrators');
		}
	}

 ?>	