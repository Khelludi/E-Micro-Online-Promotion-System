


<!-- Grid row -->
  <div class="row" style="margin-left: 80px; margin-top: 100px;">

    <!-- Grid column -->
    <div class="col-lg-5">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-2 mb-lg-0 mb-4">
        <img class="img-fluid" src="<?php echo site_url(); ?>assets/images/posts/<?php echo $post['product_image']; ?>"alt="Sample image">
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>

    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    <div class="col-lg-7">
    	<h3 class="font-weight-bold mb-3"><strong><?php echo $post['name']; ?></strong></h3>
      <!-- Category -->
      <a href="#!" class="green-text" style="text-decoration: none;"><h5 class="font-weight-bold mb-3"><i class="fa fa-cutlery pr-2"></i><?php echo $post['price']; ?></h5></a>
      <!-- Post title -->
      
      <!-- Excerpt -->
      <p><?php echo $post['description']; ?></p>
      <!-- Post data -->
      <p><a><strong>Contact us :<?php echo $post['contact']; ?></strong></a></p>
      <p class="post-date"><strong>Address:   </strong><?php echo $post['address']; ?></p><br>
      <!-- Read more button -->
      <?php if ($this->session->userdata('user_id')==$post['user_id']): ?>
      <a class="btn btn-success btn-md" href="<?php echo site_url('/products/edit/'.$post['slag']); ?>">Edit</a>
      <?php endif; ?>
    </div>
    <!-- Grid column -->

  </div>
  <!-- Grid row -->

  <hr class="my-5">