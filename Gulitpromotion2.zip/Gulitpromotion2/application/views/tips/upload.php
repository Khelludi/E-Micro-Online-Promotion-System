<h2><?=$title; ?></h2>
<?php echo validation_errors(); ?>
<?php echo form_open_multipart('tips/upload'); ?>
	<div>
		<label>Title</label>
		<input type="text" class="form-control" name="title" placeholder="Add Title">
	</div>
	<div>
		<label>Tip</label>
		<textarea  id="editor1" name="tip" placeholder="Add Tip" rows="20" cols="50"></textarea>
	</div>
	<div>
	<button type="submit" class="btn btn-default">Submit</button>
</form>