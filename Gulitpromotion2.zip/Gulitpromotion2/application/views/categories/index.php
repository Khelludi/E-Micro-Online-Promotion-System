<h2><?= $title; ?></h2>
<ul class="list-group">
	<?php foreach ($categories as $category) : ?>
		 <a style="text-decoration:none;" href="<?php  echo site_url('/categories/products/'.$category['id']);?>"> <li class="list-group-item"><h5> <?php echo $category['cname']; ?></h5></li></a>
		 <br>
	<?php endforeach; ?>

</ul>
<br>
<hr class="my-3">
 <?php if($this->session->userdata('logged_in')): ?>
<a class="btn btn-primary" style="width: 200px;"href="<?php echo base_url(); ?>categories/create">create</a>
<?php endif; ?>