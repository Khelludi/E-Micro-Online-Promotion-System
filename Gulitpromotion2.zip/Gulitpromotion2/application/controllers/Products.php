<?php 
	class Products extends CI_Controller{
		
		public function index(){
			$data['title']='Latest products';

			$data['products']=$this->productmodel->getProducts();

			$this->load->view('templates/header');
			$this->load->view('products/index',$data);
			$this->load->view('templates/footer');
		}
		public function view($slag){
			$data['post']=$this->productmodel->getProducts($slag);
			if (empty($data['post'])) {
				show_404();
			}
			$data['title']=$data['post']['name'];

			$this->load->view('templates/header');
			$this->load->view('products/view',$data);
			$this->load->view('templates/footer');
		}
		public function upload(){
			//check login
			if(!$this->session->userdata('logged_in')){
				redirect('users/login');
			}
			$data['title']='Upload Product';
			
			$data['categories']=$this->productmodel->getCategories();

			$this->form_validation->set_rules('name','Name','required');
			$this->form_validation->set_rules('description','Description','required');
			$this->form_validation->set_rules('price','Price','required');
			$this->form_validation->set_rules('contact','Contact','required');
			$this->form_validation->set_rules('address','Address','required');
			

			if ($this->form_validation->run() === False) {
				$this->load->view('templates/header');
				$this->load->view('products/upload',$data);
				$this->load->view('templates/footer');
			}else{
				//upload image
				$config['upload_path']='./assets/images/posts/';
				$config['allowed_types']='gif|jpg|png';
				$config['max_size']='2048';
				$config['max_width']='5000';
				$config['max_height']='5000';

				$this->load->library('upload',$config);
				if (!$this->upload->do_upload()) {
				$this->session->set_flashdata('post_created','Please enter correct image format (jpg)'); 
					redirect('products/upload');
				}else{
					$data=array('upload_data'=>$this->upload->data());
					$product_image=$_FILES['userfile']['name']; 
				}

				$this->productmodel->uploadProduct($product_image);
				
				$this->session->set_flashdata('post_created','Your post has been created'); 
				redirect('products');
			}
			
		}
		public function edit($slag){
			//check login
			
			if(!$this->session->userdata('logged_in')){
				redirect('users/login');
			}
			//check user
			if($this->session->userdata('user_id')!=$this->productmodel->getProducts($slag)['user_id']){
				redirect('products');
			}
			$data['post']=$this->productmodel->getProducts($slag);
			$data['categories']=$this->productmodel->getCategories();
			if (empty($data['post'])) {
				show_404();
			}
			$data['title']='Edit Post';

			$this->load->view('templates/header');
			$this->load->view('products/edit',$data);
			$this->load->view('templates/footer');
		}
		public function update(){
			//check login
			if(!$this->session->userdata('logged_in')){
				redirect('users/login');
			}
			$data['title']="Edit Post";
			$data['categories']=$this->productmodel->getCategories();
			$this->form_validation->set_rules('name','Name','required');
			$this->form_validation->set_rules('description','Description','required');
			$this->form_validation->set_rules('price','Price','required');
			$this->form_validation->set_rules('contact','Contact','required');
			$this->form_validation->set_rules('address','Address','required');
			

			if ($this->form_validation->run() === False) {
				$this->load->view('templates/header');
				$this->load->view('products/upload',$data);
				$this->load->view('templates/footer');
			}else{
				//upload image
				$config['upload_path']='./assets/images/posts';
				$config['allowed_types']='gif|jpg|png';
				$config['max_size']='2048';
				$config['max_width']='5000';
				$config['max_height']='5000';

				$this->load->library('upload',$config);
				if (!$this->upload->do_upload()) {
					$this->session->set_flashdata('login_failed',' POST NOT UPDATED! Please retry again with correct image format (jpg)'); 
					redirect( 'products');
				}else{
					$data=array('upload_data'=>$this->upload->data());
					$product_image=$_FILES['userfile']['name']; 
				}
			$this->productmodel->updateProduct($product_image);
			$this->session->set_flashdata('post_updated','Your post has been updated');
			redirect('products');
		}

}
}
 ?>