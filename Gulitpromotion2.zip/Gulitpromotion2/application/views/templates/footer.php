</div>

			<script>
  
                CKEDITOR.replace( 'editor1' );
            </script>
              <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
   
</body>
</html>
<!--- <footer class="py-5 bg-dark fixed">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Gulit Online Promotion 2018</p>
      </div>
   
    </footer>
<-->