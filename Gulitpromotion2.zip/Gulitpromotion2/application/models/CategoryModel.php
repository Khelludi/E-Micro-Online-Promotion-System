<?php 
	/**
	 * 
	 */
	class CategoryModel extends CI_Model
	{
		
		public function __construct ()
		{
			$this->load->database();
		}

		public function getCategories(){
			$this->db->order_by('cname');
			$query = $this->db->get('categories');
			return $query->result_array();
		}

		public function createCategory(){
			$data=array(
				'cname'=>$this->input->post('cname')
			);
			return $this->db->insert('categories',$data);
		}
		public function getCategory($id){
			$query=$this->db->get_where('categories',array('id'=>$id));
			return $query->row();
		}
	}


 ?>