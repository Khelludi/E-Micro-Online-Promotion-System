<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['products/upload']='products/upload';
$route['products/update']='products/update';
$route['products/(:any)'] = 'products/view/$1';
$route['products']='products/index';

$route['default_controller'] = 'pages/view';

$route['tips']='tips/index';
$route['tips/upload']='tips/upload';

$route['newses/upload']='newses/upload';
$route['newses/update']='newses/update';
$route['newses']='newses/index';
$route['newses/(:any)'] = 'newses/view/$1';

$route['adminstrators']='adminstrators/index';
$route['adminstrators/userslist']='adminstrators/userslist';

$route['categories'] ='categories/index';
$route['categories/create']='categories/create';
$route['categories/posts/(:any)']='categories/posts/$1';
$route['(:any)'] = 'pages/view/$1';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
