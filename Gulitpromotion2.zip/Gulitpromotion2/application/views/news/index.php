<h2><?=$title ?></h2>
<?php foreach ($news as $post) : ?>
		<div class="row">

    <!-- Grid column -->
    <div class="col-lg-5 col-xl-4">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-1-half mb-lg-0 mb-4">
        <img class="img-fluid" src="<?php echo site_url(); ?>assets/images/posts/<?php echo $post['news_image']; ?>" >
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>

    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    <div class="col-lg-7 col-xl-8">

      <!-- Post title -->
      <h3 class="font-weight-bold mb-3"><strong><?php echo $post['n_title']; ?></strong></h3>
      <!-- Excerpt -->
      <p class="dark-grey-text"><?php echo word_limiter($post['news'],60); ?></p>
      <!-- Post data -->
      <p class="post-date"><a ><strong>Posted on:</strong><?php echo $post['date']; ?></p>
      <!-- Read more button -->
      <br>
      <a class="btn btn-primary btn-md" href="<?php echo site_url('/newses/'.$post['n_slag']); ?>">Read more</a>

    </div>
    <!-- Grid column -->

  </div>
  <hr class="my-5">
<?php endforeach; ?>
 