<h2><?=$title; ?></h2>
<?php echo validation_errors(); ?>
<?php echo form_open_multipart('newses/upload'); ?>
<input type="hidden" name="level" value="$this->session->userdata('level')">
	<div>
		<label>Title</label>
		<input type="text" class="form-control" name="title" placeholder="Add Title">
	</div>
	<div>
		<label>News</label>
		<textarea  id="editor1" name="news" placeholder="Add Body" rows="20" cols="50"></textarea>
	</div>
	<div>
		<label>upload image:</label>
		 <input type="file" name="userfile" size="20">
	</div>
	<button type="submit" class="btn btn-default">Submit</button>
</form>