<h2><?=$title; ?></h2>
<?php echo validation_errors(); ?>
<?php echo form_open_multipart('products/update'); ?>
<input type="hidden"  name="user_id" value="<?php echo $post['user_id'] ?>">
	<div>
		<label>Name</label>
		<input type="text" class="form-control" name="name" value="<?php echo $post['name'] ?>">
	</div>
	<div>
		<label>Description</label>
		<textarea  id="editor1" name="description" placeholder="Add Description" rows="20" cols="50"><?php echo $post['description'] ?></textarea>
	</div>
	<div>
		<label>Price</label>
		<input type="text" class="form-control" name="price" value="<?php echo $post['price'] ?>">
	</div>
	<div>
		<label>Phone Number</label>
		<input type="text" class="form-control" name="contact" value="<?php echo $post['contact'] ?>">
	</div>
	<div>
		<label>Address</label>
		<input type="text" class="form-control" name="address" value="<?php echo $post['address'] ?>">
	</div>

	<div class="from-group">
		<label>Categroy</label>
		<select name="category_id" class="form-control">
			<?php foreach($categories as $category): ?>
				<option value="<?php echo $category['id']; ?>"><?php echo $category['cname']; ?></option>
			<?php endforeach; ?>
		</select>
	</div>
	<div>
		<label>upload image:</label>
		 <input type="file" name="userfile" size="20">
	</div>
	<!--<input type="hidden" name="user_id" value="<?php echo $post['user'] ?>>-->
	<button type="submit" class="btn btn-default">Submit</button>
</form>
