
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
	<title>Gulit Online Promotion</title>
	<!---<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/bootstrap.css">
	
	<link rel="stylesheet" type="text/css" href="https://bootswatch.com/4/flatly/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/style3.css">
	 <link  href="<?php echo base_url(); ?>assets/css/modern-business.css" rel="stylesheet">-->
	 <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/style.css">
	 <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url(); ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo base_url(); ?>assets/css/modern-business.css" rel="stylesheet">
	<script src="<?php echo base_url(); ?>/assets/ckeditor/ckeditor.js"></script>
</head>
<body>
	<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.html">Gulit</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url(); ?>">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url(); ?>tips/index">tips</a></li>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url(); ?>newses">news</a></li>
              <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url(); ?>adminstrators/listusers">Users</a></li>
              <li class="nav-item dropdown">
              	<li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                upload
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
                <a class="dropdown-item" href="<?php echo base_url(); ?>newses/upload">Upload news</a>
                <a class="dropdown-item" href="<?php echo base_url(); ?>tips/upload">Upload tips</a>
              </div>
            </li>
            <li class="nav-item dropdown">
             <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Account
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
                <a class="dropdown-item" href="<?php echo base_url(); ?>users/logout">Logout</a>
              </div>
            </li>
          
          </ul>
        </div>
      </div>
    </nav>
   
    <br><br>
	
<div class="container">
	<!-- Flash message-->
	<?php if($this->session->flashdata('user_registered')): ?>
		<?php echo '<p class="alert alert-successr">'.$this->session->flashdata('user_registered').'</p>'; ?>
	<?php endif; ?>
	<?php if($this->session->flashdata('post_created')): ?>
		<?php echo '<p class="alert alert-success">'.$this->session->flashdata('post_created').'</p>'; ?>
	<?php endif; ?>
	<?php if($this->session->flashdata('post_updated')): ?>
		<?php echo '<p class="alert alert-success">'.$this->session->flashdata('post_updated').'</p>'; ?>
	<?php endif; ?>
	<?php if($this->session->flashdata('Category_created')): ?>
		<?php echo '<p class="alert alert-success">'.$this->session->flashdata('caegory_created').'</p>'; ?>
	<?php endif; ?>
	<?php if($this->session->flashdata('login_failed')): ?>
		<?php echo '<p class="alert alert-danger">'.$this->session->flashdata('login_failed').'</p>'; ?>
	<?php endif; ?>
	<?php if($this->session->flashdata('user_loggedin')): ?>
		<?php echo '<p class="alert alert-success">'.$this->session->flashdata('user_loggedin').'</p>'; ?>
	<?php endif; ?>
	<?php if($this->session->flashdata('user_loggedout')): ?>
		<?php echo '<p class="alert alert-success">'.$this->session->flashdata('user_loggedout').'</p>'; ?>
	<?php endif; ?>
