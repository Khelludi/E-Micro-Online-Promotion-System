<?php 
	class TipModel extends CI_Model{
		public function __construct(){
			$this->load->database();
		}
		public function getTips($t_slug=FALSE){
			if($t_slug ===FALSE){
				$this->db->order_by('id','DESC');
				$query=$this->db->get('tips');
				return $query->result_array();
			}

			$query=$this->db->get_where('tips',array($t_slag=>$t_slag));
			return $query->row_array();
		}
		public function uploadTips(){
			$t_slag=url_title($this->input->post('title'));
			$data=array(
				'title'=>$this->input->post('title'),
				't_slag'=>$t_slag,
				'tip'=>$this->input->post('tip')

		);
			return $this->db->insert('tips',$data);
		}
	}

 ?>