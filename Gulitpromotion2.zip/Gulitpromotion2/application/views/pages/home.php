<h2 style="margin-left: 300px; margin-top: 50px;"><?=$title ?></h2>
<?php if($this->session->userdata('level')==1): ?>
<p style="margin-left: 250px;">welcome to the Gulit Online Promotion adminstrator page</p>
<?php endif; ?>
<?php if($this->session->userdata('level')==2): ?>
<h6 style="margin-left: 250px;">welcome to Your Gulit Online Promotion page</h6>
<p style="margin-left: 270px;">where you can promot your products at home</p>
<?php endif; ?>