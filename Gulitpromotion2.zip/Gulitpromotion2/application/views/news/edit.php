<h2><?=$title; ?></h2>
<?php echo validation_errors(); ?>
<?php echo form_open('newses/update'); ?>
	<input type="hidden" name="id" value="<?php echo $post['id'] ?>">
	<div>
		<label>Title</label>
		<input type="text" class="form-control" name="title" placeholder="Add Title" value="<?php echo $post['n_title']; ?>">
	</div>
	<br><br>
	<div>
		<label>News</label>
		<textarea id="editor1" type="text" name="news" placeholder="Add Body" rows="10" cols="40"><?php echo $post['news']; ?></textarea>
	</div>
	<div>
		<label>upload image:</label>
		 <input type="file" name="userfile" size="20">
	</div>
	<button type="submit" class="btn btn-primary">Submit</button>
</form>
