<h2><?=$title ?></h2>
<div class="row" >
<?php foreach ($products as $post) : ?>
<div class="col-lg-3 col-md-4 col-sm-6 portfolio-item"  style="overflow:hidden;">
          <div class="card h-80" style="width: 100%; height: 500px;">
            <a href="#"><img id="Pimage" class="card-img-top" src="<?php echo site_url(); ?>assets/images/posts/<?php echo $post['product_image']; ?>" alt=""></a>
            <div class="card-body">
              <h4 class="card-title">
                <a href="#"><?php echo $post['name']; ?></a>
              </h4>
              <p class="card-text"><?php echo word_limiter($post['description'],9); ?></p>

              <h2><?php echo $post['price']; ?></h2><hr>
              <a style="position: relative;
  margin-top: -10px;
 ;"href="<?php echo site_url('/products/'.$post['slag']); ?>" class="btn btn-primary btn-md">Read More</a>
            </div>
            
          </div>
          
        </div>
 
<?php endforeach; ?>
</div>