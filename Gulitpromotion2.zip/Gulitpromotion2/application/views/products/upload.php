<h2><?=$title; ?></h2>
<?php echo validation_errors(); ?>
<?php echo form_open_multipart('products/upload'); ?>
	<div>
		<input type="hidden" name="user_id" value="$this->session->userdata('user_id')">
	</div>
	<div>
		<label>Name</label>
		<input type="text" class="form-control" name="name" placeholder="Add Title">
	</div>
	<div>
		<label>Description</label>
		<textarea  id="editor1" name="description" placeholder="Add Description" rows="20" cols="50"></textarea>
	</div>
	<div>
		<label>Price</label>
		<input type="text" class="form-control" name="price" placeholder="Add Price">
	</div>
	<div>
		<label>Phone Number</label>
		<input type="text" class="form-control" name="contact" placeholder="Add contact">
	</div>
	<div>
		<label>Address</label>
		<input type="text" class="form-control" name="address" placeholder="Add Address">
	</div>

	<div class="from-group">
		<label>Categroy</label>
		<select name="category_id" class="form-control">
			<?php foreach($categories as $category): ?>
				<option value="<?php echo $category['id']; ?>"><?php echo $category['cname']; ?></option>
			<?php endforeach; ?>
		</select>
	</div>
	<div>
		<label>upload image:</label>
		 <input type="file" name="userfile" size="20">
	</div>
	<button type="submit" class="btn btn-default">Submit</button>
</form>
