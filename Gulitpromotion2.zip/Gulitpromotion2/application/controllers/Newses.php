<?php 
	class Newses extends CI_Controller{
		public function index(){
			$data['title']='Latest News';
			$data['news']=$this->newsmodel->getNews();
			$this->load->view('templates/header');
			$this->load->view('news/index',$data);
			$this->load->view('templates/footer');
		}

	public function view($n_slag=NULL){
			$data['post']=$this->newsmodel->getNews($n_slag);
			if (empty($data['post'])) {
				show_404();
			}
			$data['title']=$data['post']['n_title'];

			$this->load->view('templates/header');
			$this->load->view('news/view',$data);
			$this->load->view('templates/footer');
		}
		public function upload(){
			//check login
			if(!$this->session->userdata('logged_in')){
				redirect('users/login');
			}
			$data['title']='Create News';

			$this->form_validation->set_rules('title','Title','required');
			$this->form_validation->set_rules('news','Body','required');

			if ($this->form_validation->run() === False) {
				$this->load->view('templates/header');
				$this->load->view('news/upload',$data);
				$this->load->view('templates/footer');
			}else{
				//upload image
				$config['upload_path']='./assets/images/posts';
				$config['allowed_types']='gif|jpg|png';
				$config['max_size']='2048';
				$config['max_width']='5000';
				$config['max_height']='5000';

				$this->load->library('upload',$config);
				if (!$this->upload->do_upload()) {
					$errors=array('error'=>$this->upload->display_errors());
					$news_image='newsimage.jpg';
				}else{
					$data=array('upload_data'=>$this->upload->data());
					$news_image=$_FILES['userfile']['name']; 
				}

				$this->newsmodel->uploadNews($news_image);
				$this->session->set_flashdata('post_created','Your News has been Uploaded'); 
				redirect('newses');
			}
			
		}
		public function edit($n_slag){
			if(!$this->session->userdata('logged_in')){
				redirect('users/login');
			}
			//check user
			if(!$this->session->userdata('level')=='1'){
				redirect('newses');
			}

			$data['post']=$this->newsmodel->getNews($n_slag);
			if (empty($data['post'])) {
				show_404(); 
			}
			$data['title']='Edit news';

			$this->load->view('templates/header');
			$this->load->view('news/edit',$data);
			$this->load->view('templates/footer');
		}
		public function update(){
			//check login
			if(!$this->session->userdata('logged_in')){
				redirect('users/login');
			}
			$data['title']='Create News';

			$this->form_validation->set_rules('title','Title','required');
			$this->form_validation->set_rules('news','Body','required');

			if ($this->form_validation->run() === False) {
				$this->load->view('templates/header');
				$this->load->view('news/upload',$data);
				$this->load->view('templates/footer');
			}else{
				//upload image
				$config['upload_path']='./assets/images/posts';
				$config['allowed_types']='gif|jpg|png';
				$config['max_size']='2048';
				$config['max_width']='5000';
				$config['max_height']='5000';

				$this->load->library('upload',$config);
				if (!$this->upload->do_upload()) {
					$errors=array('error'=>$this->upload->display_errors());
					$news_image='newsimage.jpg';
				}else{
					$data=array('upload_data'=>$this->upload->data());
					$news_image=$_FILES['userfile']['name']; 
				}

			
			$this->newsmodel->updateNews($news_image);
			$this->session->set_flashdata('post_updated','Your News has been updated');
			redirect('newses');
		}
}

}
 ?>