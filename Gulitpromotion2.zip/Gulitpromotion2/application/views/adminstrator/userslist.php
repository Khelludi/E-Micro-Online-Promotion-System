
<div class="container">
  <h1>List of users</h1>
     <br><br>      
  <table class="table table-hover">
    <thead class="blue-grey lighten-4">
      <tr>
        <th>Enterprise Name</th>
        <th>User Name</th>
        <th>Email</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($users as $post) : ?>
      <tr>
        <td><?php echo $post['enterprise_name']; ?></td>
        <td><?php echo $post['username']; ?></td>
        <td><?php echo $post['email']; ?></td>
        <td><?php echo form_open('/adminstrators/delete/'.$post['id']); ?>
		<input type="submit" value="delete" class="btn btn-danger" >
		</form></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>


