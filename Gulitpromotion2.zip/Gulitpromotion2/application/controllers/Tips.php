<?php 
	class Tips extends CI_Controller{
		public function index(){
			$data['title']='Tips';
			$data['tips']=$this->tipmodel->getTips();
			$this->load->view('templates/header');
			$this->load->view('tips/index',$data);
			$this->load->view('templates/footer');
		}
		public function view($t_slag=NULL){
			$data['tip']=$this->tipmodel->getTips($t_slag);
			if (empty($data['tip'])) {
				show_404();
			}
			$data['title']=$data['post']['name'];

			$this->load->view('templates/header');
			$this->load->view('tips/view',$data);
			$this->load->view('templates/footer');
		}
		public function upload(){
			if(!$this->session->userdata('logged_in')){
				redirect('users/login');
			}
			$data['title']='Create Tips';
			$this->form_validation->set_rules('title','Title','required');
			$this->form_validation->set_rules('tip','Tip','required');
			if ($this->form_validation->run() === False) {
			$this->load->view('templates/header2');
			$this->load->view('tips/upload',$data);
			$this->load->view('templates/footer');
		}else{
			$this->tipmodel->uploadTips();
			$this->session->set_flashdata('post_created','Tip has been uploaded'); 
			redirect('tips');
		}
	}	
}


 ?>