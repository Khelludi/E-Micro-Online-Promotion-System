

<?php echo form_open('users/register'); ?>
<div class="row">
	<div class="col-md-4"></div>
	<div class="col-md-4 col-md-offset-4">
	<h1 class="text-center"><?= $title;?></h1>
	<?php echo validation_errors(); ?>
	<div class="form-group">
		<label>Enterprise Name</label>
		<input type="text" name="enterprise_name" placeholder="Enterprise Name" class="form-control">
	</div>
	<div class="form-group">
		<label>License number</label>
		<input type="text" name="license_number" placeholder="License Number" class="form-control">
	</div>
	<div class="form-group">
		<label>Email</label>
		<input type="email" name="email" placeholder="Email" class="form-control">
	</div>
	<div class="form-group">
		<label>username</label>
		<input type="text" name="username" placeholder="username" class="form-control">
	</div>
	<div class="form-group">
		<label>password</label>
		<input type="password" name="password" placeholder="Password" class="form-control">
	</div>
	<div class="form-group">
		<label>Confirm password</label>
		<input type="password" name="password2" placeholder="Confirm password" class="form-control">
	</div>
	<button type="submit" class="btn btn-primary btn-block">submit</button>
	</div>
</div>

<?php echo form_close(); ?>