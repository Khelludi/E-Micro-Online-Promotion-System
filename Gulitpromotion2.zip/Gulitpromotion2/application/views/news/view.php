<h2 class="font-weight-bold mb-3"><?php echo $post['n_title']; ?></h2>
<small class="post-date"><strong>Posted on:</strong><?php echo $post['date']; ?></small><br>
<img class="post-thumb-view" src="<?php echo site_url(); ?>assets/images/posts/<?php echo $post['news_image']; ?>">
<div class="post-body">
	<?php echo $post['news']; ?>
</div>

<hr>
<?php if ($this->session->userdata('level')==$post['level']): ?>
<a class="btn btn-primary" href="<?php echo site_url('/newses/edit/'.$post['n_slag']); ?>">Edit</a>
<?php endif; ?>




