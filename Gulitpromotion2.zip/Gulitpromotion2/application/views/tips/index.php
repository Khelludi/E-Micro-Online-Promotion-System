<h2><?= $title; ?></h2>
<div class="row" >
<?php foreach($tips as $post): ?>
		<div class="col-md-5" id="box" style="box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.2), 0 2px 3px 0 rgba(0, 0, 0, 0.19);">
	<h3 class="card-title"><?php echo $post['title']; ?></h3>
	<div class="card-text">
	<p ><?php echo $post['tip']; ?></p>
	<br>
	<small class="post-date"><strong>Created at:</strong><?php echo $post['date']; ?></small></div>
	
	</div>
	
<?php endforeach; ?>
</div>

